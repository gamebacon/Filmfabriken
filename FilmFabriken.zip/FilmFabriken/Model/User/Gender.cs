﻿namespace FilmFabriken.Model.User
{
    public enum Gender
    {
        Male,
        Female,
        Apache_Helicopter
    }
}