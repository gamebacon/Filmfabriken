﻿namespace FilmFabriken.wwwroot.cs
{
    public static class Role
    {
        public const string _default = "admin";
        public const string Admin = "admin";
        public const string all = "default,admin";
    }
}